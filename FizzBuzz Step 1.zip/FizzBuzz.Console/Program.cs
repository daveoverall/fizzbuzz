﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(FizzBuzzEngine.Execute(1, 20));
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz.ConsoleApp
{
    public static class FizzBuzzEngine
    {
        public static string Execute(int starting, int ending)
        {
            var fizzCount = 0;
            var buzzCount = 0;
            var fizzbuzzCount = 0;
            var luckyCount = 0;
            var integerCount = 0;

            return Execute(starting, ending, out fizzCount, out buzzCount, out fizzbuzzCount, out luckyCount, out integerCount);
        }

        public static string Execute(int starting, int ending, out int fizzCount, out int buzzCount, out int fizzbuzzCount, out int luckyCount, out int integerCount)
        {
            if (starting < 0)
            {
                throw new ArgumentOutOfRangeException("starting", "Value must be greater than or equal to zero.");
            }

            if (ending < 0)
            {
                throw new ArgumentOutOfRangeException("ending", "Value must be greater than or equal to zero.");
            }

            if (ending < starting)
            {
                throw new ArgumentOutOfRangeException("ending", "Ending value must be greater than starting value.");
            }

            fizzCount = 0;
            buzzCount = 0;
            fizzbuzzCount = 0;
            luckyCount = 0;
            integerCount = 0;

            var results = new List<string>();

            for (int n = starting; n <= ending; n++)
            {
                if (n.ToString().Contains("3"))
                {
                    results.Add("lucky");
                    luckyCount++;
                }
                else if (n % 15 == 0)
                {
                    results.Add("fizzbuzz");
                    fizzbuzzCount++;
                }
                else if (n % 3 == 0)
                {
                    results.Add("fizz");
                    fizzCount++;
                }
                else if (n % 5 == 0)
                {
                    results.Add("buzz");
                    buzzCount++;
                }
                else
                {
                    results.Add(n.ToString());
                    integerCount++;
                }
            }

            return string.Join(" ", results);
        }
    }
}

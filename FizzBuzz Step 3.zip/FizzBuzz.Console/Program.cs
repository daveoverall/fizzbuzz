﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var fizzCount = 0;
            var buzzCount = 0;
            var fizzbuzzCount = 0;
            var luckyCount = 0;
            var integerCount = 0;

            Console.WriteLine(FizzBuzzEngine.Execute(1, 20, out fizzCount, out buzzCount, out fizzbuzzCount, out luckyCount, out integerCount));
            Console.WriteLine(string.Format("{0}: {1}", "fizz", fizzCount));
            Console.WriteLine(string.Format("{0}: {1}", "buzz", buzzCount));
            Console.WriteLine(string.Format("{0}: {1}", "fizzbuzz", fizzbuzzCount));
            Console.WriteLine(string.Format("{0}: {1}", "lucky", luckyCount));
            Console.WriteLine(string.Format("{0}: {1}", "integer", integerCount));

            Console.ReadLine();
        }
    }
}

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FizzBuzz.ConsoleApp;

namespace FizzBuzz.Tests
{
    [TestClass]
    public class FizzBuzzTests
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CheckArgumentOne()
        {
            FizzBuzzEngine.Execute(-1, 10);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CheckArgumentTwo()
        {
            FizzBuzzEngine.Execute(0, -1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CheckArgumentRange()
        {
            FizzBuzzEngine.Execute(20, 0);
        }

        [TestMethod]
        public void CheckFizz()
        {
            var returnValue = FizzBuzzEngine.Execute(6, 6);

            Assert.AreEqual("fizz",returnValue);
        }

        [TestMethod]
        public void CheckBuzz()
        {
            var returnValue = FizzBuzzEngine.Execute(5, 5);

            Assert.AreEqual("buzz", returnValue);
        }

        [TestMethod]
        public void CheckFizzBuzz()
        {
            var returnValue = FizzBuzzEngine.Execute(15, 15);

            Assert.AreEqual("fizzbuzz", returnValue);
        }

        [TestMethod]
        public void CheckLucky()
        {
            var returnValue = FizzBuzzEngine.Execute(3, 3);

            Assert.AreEqual("lucky", returnValue);

            returnValue = FizzBuzzEngine.Execute(13, 13);

            Assert.AreEqual("lucky", returnValue);
        }

        [TestMethod]
        public void CheckFizzBuzzRange()
        {
            var returnValue = FizzBuzzEngine.Execute(1, 20);

            Assert.AreEqual("1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz", returnValue);
        }

        [TestMethod]
        public void CheckFizzBuzzRangeSummary()
        {
            var fizzCount = 0;
            var buzzCount = 0;
            var fizzbuzzCount = 0;
            var luckyCount = 0;
            var integerCount = 0;

            var returnValue = FizzBuzzEngine.Execute(1, 20, out fizzCount, out buzzCount, out fizzbuzzCount, out luckyCount, out integerCount);

            Assert.AreEqual(4, fizzCount);
            Assert.AreEqual(3, buzzCount);
            Assert.AreEqual(1, fizzbuzzCount);
            Assert.AreEqual(2, luckyCount);
            Assert.AreEqual(10, integerCount);
        }
    }
}

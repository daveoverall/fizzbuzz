﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz.ConsoleApp
{
    public static class FizzBuzzEngine
    {
        public static string Execute(int starting, int ending)
        {
            if (starting < 0)
            {
                throw new ArgumentOutOfRangeException("starting", "Value must be greater than or equal to zero.");
            }

            if (ending < 0)
            {
                throw new ArgumentOutOfRangeException("ending", "Value must be greater than or equal to zero.");
            }

            if (ending < starting)
            {
                throw new ArgumentOutOfRangeException("ending", "Ending value must be greater than starting value.");
            }

            var results = new List<string>();

            for (int n = starting; n <= ending; n++)
            {
                if (n.ToString().Contains("3"))
                {
                    results.Add("lucky");
                }
                else if (n % 15 == 0)
                {
                    results.Add("fizzbuzz");
                }
                else if (n % 3 == 0)
                {
                    results.Add("fizz");
                }
                else if (n % 5 == 0)
                {
                    results.Add("buzz");
                }
                else
                {
                    results.Add(n.ToString());
                }
            }

            return string.Join(" ", results);
        }
    }
}
